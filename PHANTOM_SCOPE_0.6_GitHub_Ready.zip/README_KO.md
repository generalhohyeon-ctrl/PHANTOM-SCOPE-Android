# PHANTOM SCOPE Android 0.6

최신 PHANTOM SCOPE 0.6 화면을 Android 앱 내부에 넣은 프로젝트입니다.

## 포함 기능
- Android SensorManager 자기장 센서(TYPE_MAGNETIC_FIELD) 직접 연결
- 자기장 X/Y/Z 및 µT 측정값 표시
- 자기장 변화 레이더 및 한국어 음성 경고 3가지 모드
- 마이크 FFT 음향 분석, 카메라 모션 변화 표시, 기기 움직임 센서
- 탐사 기록 및 CSV 내보내기

## APK 빌드
`.github/workflows/build-apk.yml` GitHub Actions 설정을 포함합니다.
프로젝트 파일을 GitHub 저장소에 올리고 Actions에서 빌드하면
`phantom-scope-debug-apk` 아티팩트로 APK가 생성됩니다.

## 휴대폰 설치
APK를 다운로드해 `app-debug.apk`를 누릅니다.
설치가 차단되면 Android 설정에서 다운로드에 사용한 앱의
'이 출처의 앱 설치 허용'을 켜야 할 수 있습니다.

## 주의
이 대화 환경에는 Android SDK/Gradle 빌드 도구가 없어 APK 바이너리 자체를 컴파일하거나
실제 갤럭시에서 테스트하지 못했습니다. 최종 APK는 온라인 빌드가 필요합니다.
자기장 측정값은 자석, 스피커, 금속, 전원장치, 기기 방향의 영향을 받습니다.
이 앱은 환경 센서 측정 도구이며 귀신이나 초자연 현상을 검증하지 않습니다.
