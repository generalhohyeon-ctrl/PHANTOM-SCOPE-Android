# PHANTOM SCOPE 0.6 기준 복구 빌드 패키지

이 패키지는 기존 0.6 프로젝트를 기준으로 한 화면 복구 진단용 빌드입니다.
카메라 플래시/자동 사진 촬영 기능은 포함하지 않습니다. 0.6 원본의 기능과 화면을 우선 확인하기 위한 기준본입니다.

## GitHub 적용 방법
1. PC에서 이 ZIP을 압축 해제합니다.
2. GitHub 저장소 `PHANTOM-SCOPE-Android`의 `main` 브랜치에서 기존 파일을 정리한 뒤, 압축 해제한 폴더 안의 모든 파일과 폴더를 저장소 최상위에 업로드합니다.
3. `.github/workflows/build-apk.yml`도 포함되어 있으므로 기존 workflow를 교체합니다.
4. Actions에서 `Build PHANTOM SCOPE APK`를 실행합니다.
5. 성공하면 `phantom-scope-0.6-baseline-apk` artifact에서 APK를 받습니다.

중요: 이 빌드는 0.6 화면이 기기에서 정상 표시되는지 확인하기 위한 기준 테스트입니다. 실제 휴대폰 테스트 전에는 화면 복구를 보장하지 않습니다.
