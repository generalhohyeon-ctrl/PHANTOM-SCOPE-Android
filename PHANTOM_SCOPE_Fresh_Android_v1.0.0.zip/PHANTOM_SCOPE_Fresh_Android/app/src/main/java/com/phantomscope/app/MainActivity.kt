package com.phantomscope.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 10, 18)
    private val panel = Color.rgb(22, 23, 36)
    private val purple = Color.rgb(173, 145, 255)
    private val muted = Color.rgb(158, 158, 180)
    private lateinit var body: LinearLayout
    private var currentTab = "레이더"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.rgb(5, 6, 11)
        window.decorView.systemUiVisibility = 0
        showApp()
    }

    private fun showApp() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(14), dp(18), dp(8))
        }

        val header = TextView(this).apply {
            text = "PHANTOM SCOPE"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
        }
        root.addView(header)

        val subtitle = TextView(this).apply {
            text = "PARANORMAL FIELD INTERFACE  •  v1.0.0"
            textSize = 10f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(14))
        }
        root.addView(subtitle)

        root.addView(sectionLabel("자기장 스펙트럼"))
        root.addView(spectrumPanel())

        val scroll = ScrollView(this)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, dp(12))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        listOf("레이더", "사운드", "카메라", "기록").forEach { tab ->
            val b = Button(this).apply {
                text = tab
                textSize = 11f
                isAllCaps = false
                setTextColor(if (tab == currentTab) purple else muted)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    currentTab = tab
                    showBody()
                    for (i in 0 until nav.childCount) {
                        (nav.getChildAt(i) as Button).setTextColor(
                            if ((nav.getChildAt(i) as Button).text == currentTab) purple else muted
                        )
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(nav)
        setContentView(root)
        showBody()
    }

    private fun showBody() {
        body.removeAllViews()
        when (currentTab) {
            "레이더" -> {
                body.addView(sectionLabel("실시간 탐사 레이더"))
                val radar = TextView(this).apply {
                    text = "◎\n\n대기 중\n\n센서 연결은 다음 개발 단계에서 활성화됩니다."
                    gravity = Gravity.CENTER
                    textSize = 19f
                    setTextColor(Color.WHITE)
                    setBackgroundColor(panel)
                    setPadding(dp(16), dp(30), dp(16), dp(30))
                }
                body.addView(radar, LinearLayout.LayoutParams(-1, dp(270)))
                body.addView(note("현재는 새 프로젝트의 화면 표시를 확인하는 기본 버전입니다. 실제 탐지값을 측정하거나 귀신을 판별하지 않습니다."))
            }
            "사운드" -> {
                body.addView(sectionLabel("오디오 분석"))
                body.addView(infoCard("마이크", "아직 연결되지 않았습니다."))
                body.addView(infoCard("LOW · MID · HIGH", "--   /   --   /   --"))
                body.addView(note("마이크 권한과 실시간 오디오 분석은 화면 안정성을 확인한 뒤 별도 단계에서 추가합니다."))
            }
            "카메라" -> {
                body.addView(sectionLabel("카메라"))
                body.addView(infoCard("카메라 미연결", "다음 개발 단계에서 안전하게 연결합니다."))
                body.addView(note("자동 플래시와 자동 사진 촬영 기능은 포함하지 않았습니다."))
            }
            "기록" -> {
                body.addView(sectionLabel("탐사 기록"))
                body.addView(infoCard("기록 없음", "아직 저장된 이벤트가 없습니다."))
            }
        }
    }

    private fun spectrumPanel(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val colors = listOf(
            Color.rgb(55, 190, 112), Color.rgb(120, 205, 92),
            Color.rgb(230, 205, 70), Color.rgb(245, 150, 60), Color.rgb(225, 65, 75)
        )
        colors.forEach { c ->
            val segment = View(this).apply { setBackgroundColor(c) }
            val lp = LinearLayout.LayoutParams(0, dp(8), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            bar.addView(segment, lp)
        }
        box.addView(bar)
        val label = TextView(this).apply {
            text = "정상 범위 표시 예시  •  센서 연결 전"
            textSize = 11f
            setTextColor(muted)
            setPadding(0, dp(10), 0, 0)
        }
        box.addView(label)
        return box
    }

    private fun sectionLabel(s: String) = TextView(this).apply {
        text = s
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setPadding(0, dp(8), 0, dp(10))
    }

    private fun infoCard(title: String, detail: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        box.addView(TextView(this).apply {
            text = title; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
        })
        box.addView(TextView(this).apply {
            text = detail; textSize = 13f; setTextColor(muted); setPadding(0, dp(8), 0, 0)
        })
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        box.layoutParams = lp
        return box
    }

    private fun note(s: String) = TextView(this).apply {
        text = s
        textSize = 12f
        setTextColor(muted)
        setPadding(dp(4), dp(12), dp(4), dp(12))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
