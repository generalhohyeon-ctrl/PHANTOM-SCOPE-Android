# PHANTOM SCOPE — 새 Android 프로젝트 v1.0.0

## 이번 단계의 목표
먼저 Android 네이티브 화면이 검은 화면 없이 정상 표시되는지 확인하는 최소 기반 프로젝트입니다.

- WebView를 사용하지 않습니다.
- HTML/JavaScript 자산을 로드하지 않습니다.
- 카메라, 마이크, 플래시, 자동 촬영 권한과 기능은 아직 포함하지 않았습니다.
- 자기장 스펙트럼은 현재 UI 예시이며 실제 센서 데이터가 아닙니다.
- 레이더/사운드/카메라/기록 탭은 화면 뼈대만 제공합니다.

## GitHub 적용
1. 새 GitHub 저장소를 만들거나 기존 저장소의 파일을 정리합니다.
2. 이 ZIP의 **내용물**을 저장소 최상위에 업로드합니다.
3. `.github/workflows/build-apk.yml` 파일이 포함됐는지 확인합니다.
4. Actions에서 `Build PHANTOM SCOPE APK` 실행을 확인합니다.
5. 성공하면 `phantom-scope-v1.0.0-debug` Artifact를 다운로드하고 압축을 풀어 `app-debug.apk`를 설치합니다.

## 빌드 환경
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk 35 / minSdk 23

이 프로젝트는 소스 패키지이며, 실제 갤럭시 기기 설치 테스트는 아직 수행되지 않았습니다.
