package com.phantomscope.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.provider.MediaStore
import android.util.Base64
import java.io.OutputStream
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import kotlin.math.sqrt
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceError
import android.webkit.ConsoleMessage
import android.view.ViewGroup
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity(), SensorEventListener {
    private lateinit var webView: WebView
    private lateinit var sensorManager: SensorManager
    private var magneticSensor: Sensor? = null
    private var pendingWebPermission: PermissionRequest? = null
    private var pendingResources: Array<String> = emptyArray()
    private val permissionRequestCode = 501
    @Volatile private var audioRecord: AudioRecord? = null
    @Volatile private var audioThread: Thread? = null
    @Volatile private var audioLevel = 0.0
    @Volatile private var lowLevel = 0.0
    @Volatile private var midLevel = 0.0
    @Volatile private var highLevel = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 8, 13)
        window.navigationBarColor = android.graphics.Color.rgb(7, 8, 13)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        magneticSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(7, 8, 13))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) {
                    val message = "화면을 불러오지 못했습니다. 오류 코드: ${error.errorCode}"
                    view.post {
                        view.loadDataWithBaseURL(
                            "https://appassets.androidplatform.net/",
                            "<html><meta name='viewport' content='width=device-width,initial-scale=1'><body style='margin:0;background:#07080d;color:#fff;font:16px sans-serif;padding:28px'><h2>PHANTOM SCOPE</h2><p>$message</p><p>앱을 종료한 뒤 다시 실행해 주세요.</p></body></html>",
                            "text/html", "UTF-8", null
                        )
                    }
                }
            }
        }
        webView.addJavascriptInterface(NativeSensors(), "AndroidSensors")
        webView.addJavascriptInterface(NativeAudio(), "AndroidAudio")
        webView.addJavascriptInterface(NativeCamera(), "AndroidCamera")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                android.util.Log.e("PHANTOM_WEB", "${consoleMessage.message()} -- ${consoleMessage.sourceId()}:${consoleMessage.lineNumber()}")
                return true
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (isFinishing || isDestroyed || request.origin.host != "appassets.androidplatform.net") {
                        request.deny()
                        return@runOnUiThread
                    }
                    // Grant only the media resources explicitly requested by this trusted app origin.
                    val allowed = request.resources.filter {
                        it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                            it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
                    }.toTypedArray()
                    if (allowed.isEmpty()) {
                        request.deny()
                        return@runOnUiThread
                    }
                    val needed = mutableListOf<String>()
                    if (allowed.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) &&
                        checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        needed.add(Manifest.permission.RECORD_AUDIO)
                    }
                    if (allowed.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) &&
                        checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        needed.add(Manifest.permission.CAMERA)
                    }
                    if (needed.isEmpty()) {
                        request.grant(allowed)
                    } else {
                        pendingWebPermission = request
                        pendingResources = allowed
                        requestPermissions(needed.toTypedArray(), permissionRequestCode)
                    }
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingWebPermission === request) {
                    pendingWebPermission = null
                    pendingResources = emptyArray()
                }
            }
        }

        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    inner class NativeAudio {
        @JavascriptInterface
        fun start(): Boolean {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), permissionRequestCode + 1) }
                return false
            }
            if (audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) return true
            stop()
            val sampleRate = 16000
            val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuffer <= 0) return false
            return try {
                val recorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuffer, 4096))
                if (recorder.state != AudioRecord.STATE_INITIALIZED) { recorder.release(); return false }
                audioRecord = recorder
                recorder.startRecording()
                if (recorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) { stop(); return false }
                audioThread = Thread {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
                    val buffer = ShortArray(1024)
                    while (!Thread.currentThread().isInterrupted && audioRecord === recorder && recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        val count = recorder.read(buffer, 0, buffer.size)
                        if (count > 0) {
                            var sum = 0.0
                            for (i in 0 until count) { val v = buffer[i] / 32768.0; sum += v * v }
                            audioLevel = (sqrt(sum / count) * 350.0).coerceIn(0.0, 100.0)
                            lowLevel = bandEnergy(buffer, count, sampleRate, 100.0)
                            midLevel = bandEnergy(buffer, count, sampleRate, 1000.0)
                            highLevel = bandEnergy(buffer, count, sampleRate, 4000.0)
                        } else if (count < 0) break
                    }
                }.also { it.name = "PhantomAudioRecord"; it.start() }
                true
            } catch (_: Exception) { stop(); false }
        }

        @JavascriptInterface fun stop() { stopNativeAudio() }
        @JavascriptInterface fun level(): Double = audioLevel
        @JavascriptInterface fun bands(): String = "$lowLevel,$midLevel,$highLevel"
    }

    private fun bandEnergy(samples: ShortArray, count: Int, sampleRate: Int, frequency: Double): Double {
        val coeff = 2.0 * kotlin.math.cos(2.0 * Math.PI * frequency / sampleRate)
        var q1 = 0.0; var q2 = 0.0
        for (i in 0 until count) { val q0 = coeff * q1 - q2 + samples[i] / 32768.0; q2 = q1; q1 = q0 }
        val power = (q1*q1 + q2*q2 - coeff*q1*q2).coerceAtLeast(0.0)
        return (sqrt(power) * 3.0).coerceIn(0.0, 100.0)
    }

    private fun stopNativeAudio() {
        val recorder = audioRecord
        audioRecord = null
        audioThread?.interrupt(); audioThread = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        audioLevel = 0.0; lowLevel = 0.0; midLevel = 0.0; highLevel = 0.0
    }

    inner class NativeCamera {
        @JavascriptInterface
        fun savePhoto(dataUrl: String): String {
            return try {
                val comma = dataUrl.indexOf(',')
                if (comma < 0 || !dataUrl.startsWith("data:image/")) return "ERROR:INVALID_IMAGE"
                val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
                if (bytes.isEmpty() || bytes.size > 12 * 1024 * 1024) return "ERROR:IMAGE_SIZE"
                val name = "PHANTOM_SCOPE_${System.currentTimeMillis()}.jpg"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PHANTOM_SCOPE")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return "ERROR:MEDIA_STORE"
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: run { contentResolver.delete(uri, null, null); return "ERROR:WRITE" }
                val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
                "SAVED:$name"
            } catch (e: Exception) { "ERROR:${e.javaClass.simpleName}" }
        }
    }

    inner class NativeSensors {
        @JavascriptInterface
        fun startMagnetometer(): Boolean {
            val sensor = magneticSensor ?: return false
            return runCatching {
                sensorManager.registerListener(this@MainActivity, sensor, SensorManager.SENSOR_DELAY_NORMAL)
            }.getOrDefault(false)
        }

        @JavascriptInterface
        fun stopMagnetometer() {
            sensorManager.unregisterListener(this@MainActivity, magneticSensor)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_MAGNETIC_FIELD || !::webView.isInitialized) return
        val x = event.values.getOrNull(0) ?: return
        val y = event.values.getOrNull(1) ?: return
        val z = event.values.getOrNull(2) ?: return
        webView.post {
            val js = "window.onNativeMagneticReading && window.onNativeMagneticReading($x,$y,$z);"
            webView.evaluateJavascript(js, null)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            val request = pendingWebPermission
            if (request != null) {
                val allGranted = permissions.isNotEmpty() &&
                    grantResults.isNotEmpty() &&
                    grantResults.all { it == PackageManager.PERMISSION_GRANTED }
                if (allGranted) request.grant(pendingResources) else request.deny()
            }
            pendingWebPermission = null
            pendingResources = emptyArray()
        }
    }

    override fun onPause() {
        stopNativeAudio()
        if (::webView.isInitialized) webView.onPause()
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        stopNativeAudio()
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidSensors")
            webView.removeJavascriptInterface("AndroidCamera")
            webView.destroy()
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
